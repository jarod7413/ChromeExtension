
0.2.1 / 2014-08-06 
==================

  * remove link
  * add travis-ci

0.2.0 / 2014-07-10
==================

  * remove tfs

0.1.1 / 2013-11-21
==================

  * delay to eval script
  * add doc
  * support qn

0.1.0 / 2013-11-15
==================

  * update readme
  * add bin
  * add tips for taobao
  * remove repeat code
  * Release 0.0.9
  * Merge pull request #5 from fengmk2/improve-performance
  * add quality options for shot()
  * add error name
  * delete base64 size check; support open url fail detach; custom log filepath.
  * Release 0.0.8
  * Merge pull request #4 from fengmk2/add-pid-to-stream
  * test err first
  * add phantomjs pid to stream.pid
  * Release 0.0.7
  * Merge pull request #3 from fengmk2/hotfix-linux-stdout
  * hot fix linux stdout
  * add history
  * Release 0.0.6
  * Merge pull request #2 from fengmk2/render-to-stdout
  * fix debug doc
  * send to stdout directly; add logger for phantomjs script

0.0.9 / 2013-09-13
==================

  * Merge pull request #5 from fengmk2/improve-performance
  * add quality options for shot()
  * add error name
  * delete base64 size check; support open url fail detach; custom log filepath.

0.0.8 / 2013-09-12
==================

  * Merge pull request #4 from fengmk2/add-pid-to-stream
  * test err first
  * add phantomjs pid to stream.pid

0.0.7 / 2013-09-12
==================

  * Merge pull request #3 from fengmk2/hotfix-linux-stdout
  * hot fix linux stdout
  * add history

0.0.6 / 2013-09-11
==================

  * Merge pull request #2 from fengmk2/render-to-stdout
  * fix debug doc
  * send to stdout directly; add logger for phantomjs script
  * Release v0.0.5
  * Merge pull request #1 from fengmk2/patch-1
  * Update tfs and utility.
  * Release v0.0.4
  * use default if not exist
  * use blanket
  * fix readme
  * add dependese version
  * Release v0.0.3
  * Release v0.0.2
  * rm close
