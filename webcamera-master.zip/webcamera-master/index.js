module.exports = require('./lib/web_camera');
